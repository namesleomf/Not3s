export type Theme = 'paper-white' | 'oled-black' | 'system';
export type UIDensity = 'compact' | 'comfortable';
export type FontScale = 'small' | 'default' | 'large';

export interface Settings {
  theme: Theme;
  uiDensity: UIDensity;
  fontScale: FontScale;
  sidebarCollapsed: boolean;
  showSidebarMetadata: boolean;
  defaultLandingView: 'recent' | 'favorites' | 'all';
  confirmBeforeDelete: boolean;
  translucentSidebar: boolean;
}

export interface Page {
  id: string;
  title: string;
  icon?: string;
  cover?: string;
  parentId: string | null;
  childrenIds: string[];
  blockIds: string[]; // Ordered list of top-level blocks
  tags: string[];
  linkedPageIds: string[];
  importedFrom?: string;
  importMetadata?: Record<string, any>;
  isPinned: boolean;
  isFavorite: boolean;
  isArchived: boolean;
  isTrashed: boolean;
  createdAt: number;
  updatedAt: number;
}

export type BlockType = 
  | 'paragraph' 
  | 'h1' 
  | 'h2' 
  | 'h3' 
  | 'bullet_list' 
  | 'numbered_list' 
  | 'todo' 
  | 'quote' 
  | 'divider' 
  | 'callout' 
  | 'code' 
  | 'image' 
  | 'table' 
  | 'bookmark' 
  | 'reference';

export interface Block {
  id: string;
  pageId: string;
  type: BlockType;
  content: string; // Rich text or raw string depending on block type
  metadata?: Record<string, any>; // e.g., checked state for todos, language for code, table data
  parentId: string | null; // For nested blocks (e.g., list items)
  childrenIds: string[];
  order: number;
}

export interface ImportJob {
  id: string;
  fileName: string;
  fileType: 'md' | 'html' | 'csv' | 'pdf';
  status: 'pending' | 'parsing' | 'converting' | 'complete' | 'error';
  sourceToolGuess?: string;
  parsedContent?: Partial<Block>[];
  warnings?: string[];
  errors?: string[];
  createdPages?: string[];
  createdAt: number;
}
