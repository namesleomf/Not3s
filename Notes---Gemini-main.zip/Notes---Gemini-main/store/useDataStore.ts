import { create } from 'zustand';
import { Page, Block } from '@/types';

interface DataState {
  // Normalized Data
  pages: Record<string, Page>;
  blocks: Record<string, Block>;
  
  // Actions: Pages
  setPages: (pages: Page[]) => void;
  addPage: (page: Page) => void;
  updatePage: (id: string, updates: Partial<Page>) => void;
  removePage: (id: string) => void;
  
  // Actions: Blocks
  setBlocks: (blocks: Block[]) => void;
  addBlock: (block: Block) => void;
  updateBlock: (id: string, updates: Partial<Block>) => void;
  removeBlock: (id: string) => void;
}

export const useDataStore = create<DataState>((set) => ({
  pages: {},
  blocks: {},
  
  setPages: (pages) => set({ 
    pages: Object.fromEntries(pages.map(p => [p.id, p])) 
  }),
  
  addPage: (page) => set((state) => ({ 
    pages: { ...state.pages, [page.id]: page } 
  })),
  
  updatePage: (id, updates) => set((state) => ({
    pages: { 
      ...state.pages, 
      [id]: { ...state.pages[id], ...updates, updatedAt: Date.now() } 
    }
  })),
  
  removePage: (id) => set((state) => {
    const newPages = { ...state.pages };
    delete newPages[id];
    return { pages: newPages };
  }),
  
  setBlocks: (blocks) => set((state) => ({ 
    blocks: { ...state.blocks, ...Object.fromEntries(blocks.map(b => [b.id, b])) } 
  })),
  
  addBlock: (block) => set((state) => ({ 
    blocks: { ...state.blocks, [block.id]: block } 
  })),
  
  updateBlock: (id, updates) => set((state) => ({
    blocks: { 
      ...state.blocks, 
      [id]: { ...state.blocks[id], ...updates } 
    }
  })),
  
  removeBlock: (id) => set((state) => {
    const newBlocks = { ...state.blocks };
    delete newBlocks[id];
    return { blocks: newBlocks };
  }),
}));
