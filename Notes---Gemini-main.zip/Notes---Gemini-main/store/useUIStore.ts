import { create } from 'zustand';
import { Theme, UIDensity, FontScale } from '@/types';

interface UIState {
  // Theme
  theme: Theme;
  setTheme: (theme: Theme) => void;

  // Sidebar
  sidebarOpen: boolean;
  toggleSidebar: () => void;
  setSidebarOpen: (open: boolean) => void;
  
  // Modals & Drawers
  activeModal: 'none' | 'settings' | 'import' | 'command-palette';
  setActiveModal: (modal: 'none' | 'settings' | 'import' | 'command-palette') => void;
  
  // Selection & Navigation
  selectedPageId: string | null;
  setSelectedPageId: (id: string | null) => void;
  
  // Search & Filters
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  activeFilter: 'all' | 'favorites' | 'trash';
  setActiveFilter: (filter: 'all' | 'favorites' | 'trash') => void;
  activeTag: string | null;
  setActiveTag: (tag: string | null) => void;

  // Editor State
  blockMenuOpen: boolean;
  setBlockMenuOpen: (open: boolean) => void;
  commandMenuOpen: boolean;
  setCommandMenuOpen: (open: boolean) => void;

  // Trading Mode
  tradingMode: boolean;
  setTradingMode: (mode: boolean) => void;
}

export const useUIStore = create<UIState>((set) => ({
  theme: 'system',
  setTheme: (theme) => set({ theme }),

  sidebarOpen: true,
  toggleSidebar: () => set((state) => ({ sidebarOpen: !state.sidebarOpen })),
  setSidebarOpen: (open) => set({ sidebarOpen: open }),
  
  activeModal: 'none',
  setActiveModal: (modal) => set({ activeModal: modal }),
  
  selectedPageId: null,
  setSelectedPageId: (id) => set({ selectedPageId: id }),
  
  searchQuery: '',
  setSearchQuery: (query) => set({ searchQuery: query }),
  
  activeFilter: 'all',
  setActiveFilter: (filter) => set({ activeFilter: filter }),
  
  activeTag: null,
  setActiveTag: (tag) => set({ activeTag: tag }),

  blockMenuOpen: false,
  setBlockMenuOpen: (open) => set({ blockMenuOpen: open }),
  
  commandMenuOpen: false,
  setCommandMenuOpen: (open) => set({ commandMenuOpen: open }),

  tradingMode: false,
  setTradingMode: (mode) => set({ tradingMode: mode }),
}));
