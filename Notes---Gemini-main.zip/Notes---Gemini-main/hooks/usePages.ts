import { useEffect, useState } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { useDataStore } from '@/store/useDataStore';
import { useUIStore } from '@/store/useUIStore';
import { Page } from '@/types';
import { loadPages, savePage, deletePage as dbDeletePage } from '@/lib/storage';

export function usePages() {
  const { pages, setPages, addPage, updatePage: storeUpdatePage, removePage } = useDataStore();
  const { setSelectedPageId, selectedPageId } = useUIStore();
  const [isLoaded, setIsLoaded] = useState(false);

  // Load pages on mount
  useEffect(() => {
    async function init() {
      const loadedPages = await loadPages();
      setPages(loadedPages);
      setIsLoaded(true);
      
      // Select first page if none selected and pages exist
      if (!selectedPageId && loadedPages.length > 0) {
        const rootPages = loadedPages.filter(p => !p.parentId && !p.isTrashed);
        if (rootPages.length > 0) {
          setSelectedPageId(rootPages[0].id);
        }
      }
    }
    init();
  }, [setPages, selectedPageId, setSelectedPageId]);

  const createPage = async (parentId: string | null = null, title: string = '') => {
    const newPage: Page = {
      id: uuidv4(),
      title,
      parentId,
      childrenIds: [],
      blockIds: [],
      tags: [],
      linkedPageIds: [],
      isPinned: false,
      isFavorite: false,
      isArchived: false,
      isTrashed: false,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };

    // Update parent if necessary
    if (parentId && pages[parentId]) {
      const parent = pages[parentId];
      const updatedParent = {
        ...parent,
        childrenIds: [...parent.childrenIds, newPage.id],
        updatedAt: Date.now(),
      };
      storeUpdatePage(parentId, updatedParent);
      await savePage(updatedParent);
    }

    addPage(newPage);
    await savePage(newPage);
    setSelectedPageId(newPage.id);
    return newPage;
  };

  const updatePage = async (id: string, updates: Partial<Page>) => {
    storeUpdatePage(id, updates);
    const updatedPage = { ...pages[id], ...updates, updatedAt: Date.now() };
    await savePage(updatedPage);
  };

  const moveToTrash = async (id: string) => {
    await updatePage(id, { isTrashed: true });
    if (selectedPageId === id) {
      setSelectedPageId(null);
    }
  };

  const permanentlyDelete = async (id: string) => {
    const page = pages[id];
    if (!page) return;

    // Remove from parent
    if (page.parentId && pages[page.parentId]) {
      const parent = pages[page.parentId];
      const updatedParent = {
        ...parent,
        childrenIds: parent.childrenIds.filter(childId => childId !== id),
        updatedAt: Date.now(),
      };
      storeUpdatePage(page.parentId, updatedParent);
      await savePage(updatedParent);
    }

    removePage(id);
    await dbDeletePage(id);
    
    // Also delete all children recursively (simplified for now, ideally should be a recursive function)
    const deleteChildren = async (childrenIds: string[]) => {
      for (const childId of childrenIds) {
        const child = pages[childId];
        if (child) {
          await deleteChildren(child.childrenIds);
          removePage(childId);
          await dbDeletePage(childId);
        }
      }
    };
    await deleteChildren(page.childrenIds);
  };

  return {
    pages,
    isLoaded,
    createPage,
    updatePage,
    moveToTrash,
    permanentlyDelete,
  };
}
