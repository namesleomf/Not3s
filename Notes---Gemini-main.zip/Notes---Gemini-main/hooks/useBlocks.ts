import { v4 as uuidv4 } from 'uuid';
import { useDataStore } from '@/store/useDataStore';
import { Block, BlockType } from '@/types';
import { saveBlock, deleteBlock as dbDeleteBlock, savePage } from '@/lib/storage';

export function useBlocks() {
  const { blocks, addBlock, updateBlock: storeUpdateBlock, removeBlock, pages, updatePage } = useDataStore();

  const createBlock = async (pageId: string, type: BlockType = 'paragraph', content: string = '', parentId: string | null = null, order: number = 0) => {
    const newBlock: Block = {
      id: uuidv4(),
      pageId,
      type,
      content,
      parentId,
      childrenIds: [],
      order,
    };

    addBlock(newBlock);
    await saveBlock(newBlock);

    // Update parent block or page
    if (parentId && blocks[parentId]) {
      const parent = blocks[parentId];
      const updatedParent = {
        ...parent,
        childrenIds: [...parent.childrenIds, newBlock.id],
      };
      storeUpdateBlock(parentId, updatedParent);
      await saveBlock(updatedParent);
    } else if (pages[pageId]) {
      const page = pages[pageId];
      // Insert at the correct order
      const newBlockIds = [...page.blockIds];
      newBlockIds.splice(order, 0, newBlock.id);
      
      const updatedPage = {
        ...page,
        blockIds: newBlockIds,
        updatedAt: Date.now(),
      };
      updatePage(pageId, updatedPage);
      await savePage(updatedPage);
    }

    return newBlock;
  };

  const updateBlock = async (id: string, updates: Partial<Block>) => {
    storeUpdateBlock(id, updates);
    const updatedBlock = { ...blocks[id], ...updates };
    await saveBlock(updatedBlock);
  };

  const deleteBlock = async (id: string) => {
    const block = blocks[id];
    if (!block) return;

    // Remove from parent
    if (block.parentId && blocks[block.parentId]) {
      const parent = blocks[block.parentId];
      const updatedParent = {
        ...parent,
        childrenIds: parent.childrenIds.filter(childId => childId !== id),
      };
      storeUpdateBlock(block.parentId, updatedParent);
      await saveBlock(updatedParent);
    } else if (pages[block.pageId]) {
      const page = pages[block.pageId];
      const updatedPage = {
        ...page,
        blockIds: page.blockIds.filter(blockId => blockId !== id),
        updatedAt: Date.now(),
      };
      updatePage(page.id, updatedPage);
      await savePage(updatedPage);
    }

    removeBlock(id);
    await dbDeleteBlock(id);
    
    // Also delete all children recursively
    const deleteChildren = async (childrenIds: string[]) => {
      for (const childId of childrenIds) {
        const child = blocks[childId];
        if (child) {
          await deleteChildren(child.childrenIds);
          removeBlock(childId);
          await dbDeleteBlock(childId);
        }
      }
    };
    await deleteChildren(block.childrenIds);
  };

  return {
    blocks,
    createBlock,
    updateBlock,
    deleteBlock,
  };
}
