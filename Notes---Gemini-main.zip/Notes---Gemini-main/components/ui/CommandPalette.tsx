import { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { Search, FileText, Settings, Plus, Trash2, Import, Activity } from 'lucide-react';
import { useUIStore } from '@/store/useUIStore';
import { useDataStore } from '@/store/useDataStore';
import { usePages } from '@/hooks/usePages';
import { Modal } from './Modal';
import { cn } from '@/lib/utils';

export function CommandPalette() {
  const { activeModal, setActiveModal, setSelectedPageId, setTradingMode, tradingMode } = useUIStore();
  const { pages } = useDataStore();
  const { createPage } = usePages();
  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  const isOpen = activeModal === 'command-palette';

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [isOpen]);

  const handleClose = useCallback(() => {
    setActiveModal('none');
    setTimeout(() => {
      setQuery('');
      setSelectedIndex(0);
    }, 200);
  }, [setActiveModal]);

  const results = useMemo(() => {
    const pageResults = Object.values(pages)
      .filter(p => !p.isTrashed && p.title.toLowerCase().includes(query.toLowerCase()))
      .map(p => ({
        id: p.id,
        title: p.title || 'Untitled',
        icon: FileText,
        action: () => {
          setSelectedPageId(p.id);
          handleClose();
        }
      }));

    const commandResults = [
      {
        id: 'new-page',
        title: 'Create New Page',
        icon: Plus,
        action: () => {
          createPage();
          handleClose();
        }
      },
      {
        id: 'settings',
        title: 'Open Settings',
        icon: Settings,
        action: () => setActiveModal('settings')
      },
      {
        id: 'import',
        title: 'Import File',
        icon: Import,
        action: () => setActiveModal('import')
      },
      {
        id: 'trading-mode',
        title: tradingMode ? 'Disable Trading Mode' : 'Enable Trading Mode',
        icon: Activity,
        action: () => {
          setTradingMode(!tradingMode);
          handleClose();
        }
      }
    ].filter(c => c.title.toLowerCase().includes(query.toLowerCase()));

    return [
      ...(query ? pageResults : []),
      ...commandResults
    ];
  }, [pages, query, tradingMode, createPage, setActiveModal, setSelectedPageId, setTradingMode, handleClose]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isOpen) {
        if (e.metaKey && e.key === 'k') {
          e.preventDefault();
          setQuery('');
          setSelectedIndex(0);
          setActiveModal('command-palette');
        }
        return;
      }

      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setSelectedIndex(i => (i + 1) % results.length);
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        setSelectedIndex(i => (i - 1 + results.length) % results.length);
      } else if (e.key === 'Enter' && results[selectedIndex]) {
        e.preventDefault();
        results[selectedIndex].action();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, results, selectedIndex, setActiveModal]);

  return (
    <Modal isOpen={isOpen} onClose={handleClose} maxWidth="max-w-2xl">
      <div className="flex flex-col -mx-5 -my-5">
        <div className="flex items-center px-4 py-3 border-b border-border-subtle">
          <Search className="w-5 h-5 text-text-muted mr-3 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            className="flex-1 bg-transparent border-none outline-none text-text-primary placeholder:text-text-muted text-lg"
            placeholder="Type a command or search..."
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setSelectedIndex(0);
            }}
          />
        </div>
        
        <div className="max-h-[60vh] overflow-y-auto p-2">
          {results.length === 0 ? (
            <div className="p-8 text-center text-text-muted text-sm">
              No results found for &quot;{query}&quot;
            </div>
          ) : (
            <div className="space-y-1">
              {results.map((result, index) => {
                const Icon = result.icon;
                const isSelected = index === selectedIndex;
                return (
                  <button
                    key={result.id}
                    onClick={result.action}
                    onMouseEnter={() => setSelectedIndex(index)}
                    className={cn(
                      "w-full flex items-center gap-3 px-3 py-2.5 rounded-[var(--radius-md)] text-left transition-all duration-200 active:scale-[0.98]",
                      isSelected ? "bg-bg-hover text-text-primary" : "text-text-secondary hover:text-text-primary"
                    )}
                  >
                    <Icon className="w-4 h-4 shrink-0" strokeWidth={1.5} />
                    <span className="text-sm font-medium">{result.title}</span>
                  </button>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </Modal>
  );
}
