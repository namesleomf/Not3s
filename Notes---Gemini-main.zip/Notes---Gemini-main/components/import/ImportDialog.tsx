import { Modal } from '@/components/ui/Modal';
import { useUIStore } from '@/store/useUIStore';
import { UploadCloud, FileText, FileSpreadsheet } from 'lucide-react';

export function ImportDialog() {
  const { activeModal, setActiveModal } = useUIStore();
  const isOpen = activeModal === 'import';
  const onClose = () => setActiveModal('none');

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Import Knowledge" maxWidth="max-w-xl">
      <div className="space-y-6">
        <div className="border-2 border-dashed border-border-strong rounded-[var(--radius-xl)] p-10 flex flex-col items-center justify-center text-center hover:bg-bg-hover transition-all duration-200 cursor-pointer active:scale-[0.98]">
          <div className="w-12 h-12 rounded-full bg-bg-elevated border border-border-subtle shadow-sm flex items-center justify-center mb-4">
            <UploadCloud className="w-6 h-6 text-text-primary" strokeWidth={1.5} />
          </div>
          <h3 className="text-base font-medium text-text-primary mb-1">Click or drag files to import</h3>
          <p className="text-sm text-text-muted max-w-xs">
            Supports Markdown (.md), HTML (.html), CSV (.csv), and PDF (.pdf) files.
          </p>
        </div>

        <div>
          <h4 className="text-xs font-medium text-text-secondary uppercase tracking-wider mb-3">Supported Formats</h4>
          <div className="grid grid-cols-2 gap-3">
            <div className="flex items-center gap-3 p-3 rounded-[var(--radius-md)] border border-border-subtle">
              <FileText className="w-5 h-5 text-text-secondary" strokeWidth={1.5} />
              <div>
                <div className="text-sm font-medium text-text-primary">Markdown</div>
                <div className="text-xs text-text-muted">Converts to blocks</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-3 rounded-[var(--radius-md)] border border-border-subtle">
              <FileSpreadsheet className="w-5 h-5 text-text-secondary" strokeWidth={1.5} />
              <div>
                <div className="text-sm font-medium text-text-primary">CSV</div>
                <div className="text-xs text-text-muted">Converts to tables</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Modal>
  );
}
