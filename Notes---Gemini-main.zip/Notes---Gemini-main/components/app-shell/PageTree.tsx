import { ChevronRight, ChevronDown, FileText, MoreHorizontal } from 'lucide-react';
import { useState } from 'react';
import { useDataStore } from '@/store/useDataStore';
import { useUIStore } from '@/store/useUIStore';
import { cn } from '@/lib/utils';

interface PageTreeItemProps {
  pageId: string;
  level?: number;
}

export function PageTreeItem({ pageId, level = 0 }: PageTreeItemProps) {
  const page = useDataStore(state => state.pages[pageId]);
  const { selectedPageId, setSelectedPageId } = useUIStore();
  const [expanded, setExpanded] = useState(false);

  if (!page || page.isTrashed) return null;

  const hasChildren = page.childrenIds && page.childrenIds.length > 0;
  const isSelected = selectedPageId === pageId;

  return (
    <div>
      <div 
        className={cn(
          "group flex items-center gap-1 px-1 py-1.5 text-sm rounded-[var(--radius-sm)] cursor-pointer transition-all duration-200 active:scale-[0.98]",
          isSelected 
            ? "bg-bg-active text-text-primary" 
            : "text-text-secondary hover:text-text-primary hover:bg-bg-hover"
        )}
        style={{ paddingLeft: `${level * 12 + 4}px` }}
        onClick={() => setSelectedPageId(pageId)}
      >
        <button 
          className={cn(
            "w-4 h-4 shrink-0 flex items-center justify-center rounded-sm hover:bg-bg-active transition-all duration-200 active:scale-90",
            !hasChildren && "opacity-0 pointer-events-none"
          )}
          onClick={(e) => {
            e.stopPropagation();
            setExpanded(!expanded);
          }}
        >
          {expanded ? (
            <ChevronDown className="w-3.5 h-3.5" strokeWidth={2} />
          ) : (
            <ChevronRight className="w-3.5 h-3.5" strokeWidth={2} />
          )}
        </button>
        
        <div className="flex items-center gap-1.5 flex-1 min-w-0">
          <span className="text-base leading-none">{page.icon || <FileText className="w-4 h-4 shrink-0 opacity-70" strokeWidth={1.5} />}</span>
          <span className="truncate">{page.title || 'Untitled'}</span>
        </div>

        <button className="opacity-0 group-hover:opacity-100 p-0.5 hover:bg-bg-active rounded-sm text-text-muted hover:text-text-primary transition-all duration-200 active:scale-90">
          <MoreHorizontal className="w-3.5 h-3.5" strokeWidth={2} />
        </button>
      </div>

      {expanded && hasChildren && (
        <div className="flex flex-col">
          {page.childrenIds.map(childId => (
            <PageTreeItem key={childId} pageId={childId} level={level + 1} />
          ))}
        </div>
      )}
    </div>
  );
}
