import { Activity, TrendingUp, TrendingDown, DollarSign } from 'lucide-react';
import { useUIStore } from '@/store/useUIStore';
import { cn } from '@/lib/utils';

export function TradingSidebar() {
  const { tradingMode } = useUIStore();

  return (
    <aside 
      className={cn(
        "surface-sidebar flex flex-col h-full shrink-0 transition-all duration-300 ease-in-out border-l border-border-subtle z-40",
        tradingMode ? "w-80 translate-x-0 opacity-100" : "w-0 translate-x-full opacity-0 overflow-hidden"
      )}
    >
      <div className="h-12 flex items-center px-4 border-b border-border-subtle shrink-0">
        <Activity className="w-4 h-4 text-emerald-500 mr-2" />
        <span className="text-sm font-medium">Market Overview</span>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        {/* Mock Portfolio */}
        <div>
          <div className="text-xs font-medium text-text-muted mb-3 uppercase tracking-wider">Portfolio Value</div>
          <div className="text-3xl font-bold font-mono tracking-tight">$124,592.45</div>
          <div className="flex items-center gap-1 text-emerald-500 text-sm mt-1 font-medium">
            <TrendingUp className="w-4 h-4" />
            <span>+$2,450.00 (2.4%)</span>
            <span className="text-text-muted ml-1">Today</span>
          </div>
        </div>

        {/* Mock Watchlist */}
        <div>
          <div className="text-xs font-medium text-text-muted mb-3 uppercase tracking-wider flex justify-between items-center">
            <span>Watchlist</span>
            <button className="text-text-primary hover:underline">Edit</button>
          </div>
          <div className="space-y-2">
            {[
              { symbol: 'AAPL', price: '178.25', change: '+1.2%', up: true },
              { symbol: 'MSFT', price: '335.12', change: '+0.8%', up: true },
              { symbol: 'GOOGL', price: '132.45', change: '-0.5%', up: false },
              { symbol: 'AMZN', price: '128.90', change: '+2.1%', up: true },
              { symbol: 'TSLA', price: '245.60', change: '-1.8%', up: false },
            ].map((stock) => (
              <div key={stock.symbol} className="flex items-center justify-between p-2 rounded-[var(--radius-sm)] hover:bg-bg-hover transition-all duration-200 cursor-pointer active:scale-[0.98]">
                <div className="font-medium">{stock.symbol}</div>
                <div className="text-right">
                  <div className="font-mono text-sm">${stock.price}</div>
                  <div className={cn("text-xs font-medium", stock.up ? "text-emerald-500" : "text-red-500")}>
                    {stock.change}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Mock Recent Activity */}
        <div>
          <div className="text-xs font-medium text-text-muted mb-3 uppercase tracking-wider">Recent Activity</div>
          <div className="space-y-3">
            {[
              { action: 'Bought', symbol: 'NVDA', amount: '10 shares', price: '$450.20', time: '2h ago' },
              { action: 'Sold', symbol: 'META', amount: '5 shares', price: '$295.50', time: '5h ago' },
            ].map((activity, i) => (
              <div key={i} className="flex items-start gap-3">
                <div className={cn(
                  "w-8 h-8 rounded-full flex items-center justify-center shrink-0 mt-0.5",
                  activity.action === 'Bought' ? "bg-emerald-500/10 text-emerald-500" : "bg-red-500/10 text-red-500"
                )}>
                  <DollarSign className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-sm font-medium">{activity.action} {activity.symbol}</div>
                  <div className="text-xs text-text-secondary">{activity.amount} @ {activity.price}</div>
                  <div className="text-xs text-text-muted mt-0.5">{activity.time}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </aside>
  );
}
