import { Search, Plus, Settings, Import, Trash2 } from 'lucide-react';
import { useUIStore } from '@/store/useUIStore';
import { useDataStore } from '@/store/useDataStore';
import { usePages } from '@/hooks/usePages';
import { PageTreeItem } from './PageTree';
import { cn } from '@/lib/utils';

export function Sidebar() {
  const { sidebarOpen, setActiveModal } = useUIStore();
  const { pages } = useDataStore();
  const { createPage } = usePages();

  // Get root pages (no parent, not trashed)
  const rootPages = Object.values(pages).filter(p => !p.parentId && !p.isTrashed);
  
  // Get favorite pages
  const favoritePages = Object.values(pages).filter(p => p.isFavorite && !p.isTrashed);

  return (
    <aside 
      className={cn(
        "surface-sidebar flex flex-col h-full w-64 shrink-0 transition-all duration-300 ease-in-out absolute md:relative z-40",
        sidebarOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0 md:w-0 md:opacity-0 md:overflow-hidden"
      )}
    >
      {/* Workspace Header */}
      <div className="h-12 flex items-center px-4 hover:bg-bg-hover cursor-pointer transition-colors shrink-0">
        <div className="w-5 h-5 rounded-[var(--radius-sm)] bg-text-primary text-bg-app flex items-center justify-center text-xs font-bold mr-2">
          L
        </div>
        <span className="text-sm font-medium truncate flex-1">Leonardo&apos;s Workspace</span>
      </div>

      {/* Quick Actions */}
      <div className="px-3 py-2 space-y-0.5 shrink-0">
        <button 
          onClick={() => setActiveModal('command-palette')}
          className="w-full flex items-center gap-2 px-2 py-1.5 text-sm text-text-secondary hover:text-text-primary hover:bg-bg-hover rounded-[var(--radius-sm)] transition-all duration-200 active:scale-95"
        >
          <Search className="w-4 h-4" strokeWidth={1.5} />
          Search
        </button>
        <button 
          onClick={() => setActiveModal('import')}
          className="w-full flex items-center gap-2 px-2 py-1.5 text-sm text-text-secondary hover:text-text-primary hover:bg-bg-hover rounded-[var(--radius-sm)] transition-all duration-200 active:scale-95"
        >
          <Import className="w-4 h-4" strokeWidth={1.5} />
          Import
        </button>
        <button 
          onClick={() => setActiveModal('settings')}
          className="w-full flex items-center gap-2 px-2 py-1.5 text-sm text-text-secondary hover:text-text-primary hover:bg-bg-hover rounded-[var(--radius-sm)] transition-all duration-200 active:scale-95"
        >
          <Settings className="w-4 h-4" strokeWidth={1.5} />
          Settings
        </button>
      </div>

      <div className="px-4 py-2 shrink-0">
        <button 
          onClick={() => createPage()}
          className="w-full flex items-center justify-center gap-2 px-3 py-1.5 text-sm font-medium text-bg-app bg-text-primary hover:opacity-90 rounded-[var(--radius-md)] transition-all duration-200 active:scale-95"
        >
          <Plus className="w-4 h-4" strokeWidth={2} />
          New Page
        </button>
      </div>

      {/* Page Tree */}
      <div className="flex-1 overflow-y-auto px-3 py-2 space-y-4">
        {favoritePages.length > 0 && (
          <div>
            <div className="text-xs font-medium text-text-muted px-2 mb-1">Favorites</div>
            <div className="flex flex-col">
              {favoritePages.map(page => (
                <PageTreeItem key={`fav-${page.id}`} pageId={page.id} />
              ))}
            </div>
          </div>
        )}

        <div>
          <div className="text-xs font-medium text-text-muted px-2 mb-1">Private</div>
          <div className="flex flex-col">
            {rootPages.map(page => (
              <PageTreeItem key={page.id} pageId={page.id} />
            ))}
            {rootPages.length === 0 && (
              <div className="text-sm text-text-muted px-2 py-1 italic">No pages yet</div>
            )}
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="p-3 shrink-0 border-t border-border-subtle">
        <button className="w-full flex items-center gap-2 px-2 py-1.5 text-sm text-text-secondary hover:text-text-primary hover:bg-bg-hover rounded-[var(--radius-sm)] transition-all duration-200 active:scale-95">
          <Trash2 className="w-4 h-4" strokeWidth={1.5} />
          Trash
        </button>
      </div>
    </aside>
  );
}
