'use client';

import { useEffect } from 'react';
import { Sidebar } from './Sidebar';
import { TopBar } from './TopBar';
import { TradingSidebar } from './TradingSidebar';
import { PageSurface } from '@/components/editor/PageSurface';
import { SettingsModal } from '@/components/settings/SettingsModal';
import { ImportDialog } from '@/components/import/ImportDialog';
import { CommandPalette } from '@/components/ui/CommandPalette';
import { FloatingToolbar } from '@/components/editor/FloatingToolbar';
import { useUIStore } from '@/store/useUIStore';

export function AppShell() {
  const { theme, sidebarOpen, setSidebarOpen } = useUIStore();

  // Handle Theme
  useEffect(() => {
    const root = window.document.documentElement;
    root.classList.remove('dark');
    if (theme === 'oled-black' || (theme === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
      root.classList.add('dark');
    }
  }, [theme]);

  return (
    <div className="flex h-screen w-full overflow-hidden surface-app">
      {/* Mobile Overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/20 dark:bg-black/40 z-30 md:hidden backdrop-blur-sm"
          onClick={() => setSidebarOpen(false)}
        />
      )}
      
      <Sidebar />
      
      <main className="flex-1 flex flex-col min-w-0 h-full relative">
        <TopBar />
        <div className="flex-1 overflow-y-auto">
          <PageSurface />
        </div>
        <FloatingToolbar />
      </main>

      <TradingSidebar />

      {/* Modals */}
      <SettingsModal />
      <ImportDialog />
      <CommandPalette />
    </div>
  );
}
