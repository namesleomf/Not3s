import { PanelLeft, MoreHorizontal, Star, Clock, Activity } from 'lucide-react';
import { useUIStore } from '@/store/useUIStore';
import { useDataStore } from '@/store/useDataStore';
import { usePages } from '@/hooks/usePages';
import { cn } from '@/lib/utils';

export function TopBar() {
  const { toggleSidebar, selectedPageId, tradingMode, setTradingMode } = useUIStore();
  const page = useDataStore(state => selectedPageId ? state.pages[selectedPageId] : null);
  const { updatePage } = usePages();

  const toggleFavorite = () => {
    if (page) {
      updatePage(page.id, { isFavorite: !page.isFavorite });
    }
  };

  return (
    <header className="h-12 flex items-center justify-between px-3 sticky top-0 bg-bg-app/80 backdrop-blur-md z-30 border-b border-border-subtle">
      <div className="flex items-center gap-2">
        <button onClick={toggleSidebar} className="icon-button w-8 h-8 md:hidden">
          <PanelLeft className="w-4 h-4" strokeWidth={1.5} />
        </button>
        <div className="text-sm font-medium text-text-secondary hover:text-text-primary cursor-pointer transition-colors px-2 py-1 rounded-[var(--radius-sm)] hover:bg-bg-hover max-w-[200px] sm:max-w-xs md:max-w-md truncate">
          Knowledge Workspace <span className="text-text-muted mx-1">/</span> {page ? (page.title || 'Untitled') : '...'}
        </div>
      </div>
      
      <div className="flex items-center gap-1">
        <button 
          onClick={() => setTradingMode(!tradingMode)}
          className={cn(
            "flex items-center gap-1.5 px-2.5 py-1.5 rounded-[var(--radius-sm)] text-xs font-medium transition-all duration-300 active:scale-95",
            tradingMode 
              ? "bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 shadow-[0_0_10px_rgba(16,185,129,0.2)]" 
              : "text-text-secondary hover:text-text-primary hover:bg-bg-hover border border-transparent"
          )}
        >
          <Activity className="w-3.5 h-3.5" strokeWidth={tradingMode ? 2 : 1.5} />
          Trading Mode
        </button>
        <div className="w-[1px] h-4 bg-border-strong mx-1" />
        <button className="icon-button w-8 h-8"><Clock className="w-4 h-4" strokeWidth={1.5} /></button>
        <button 
          onClick={toggleFavorite}
          className={cn("icon-button w-8 h-8", page?.isFavorite && "text-yellow-500 hover:text-yellow-600")}
        >
          <Star className="w-4 h-4" strokeWidth={1.5} fill={page?.isFavorite ? "currentColor" : "none"} />
        </button>
        <button className="icon-button w-8 h-8"><MoreHorizontal className="w-4 h-4" strokeWidth={1.5} /></button>
      </div>
    </header>
  );
}
