import React, { useEffect, useState } from 'react';
import { useDataStore } from '@/store/useDataStore';
import { useBlocks } from '@/hooks/useBlocks';
import { Block } from '@/types';
import { loadBlocksForPage } from '@/lib/storage';
import { BlockItem } from './BlockItem';

interface BlockEditorProps {
  pageId: string;
}

export function BlockEditor({ pageId }: BlockEditorProps) {
  const { blocks, setBlocks } = useDataStore();
  const { createBlock } = useBlocks();
  const page = useDataStore(state => state.pages[pageId]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function loadBlocks() {
      setIsLoading(true);
      const loadedBlocks = await loadBlocksForPage(pageId);
      setBlocks(loadedBlocks);
      setIsLoading(false);
    }
    loadBlocks();
  }, [pageId, setBlocks]);

  if (!page) return null;

  const handleCreateInitialBlock = () => {
    createBlock(pageId, 'paragraph', '', null, 0);
  };

  if (isLoading) {
    return <div className="text-text-muted py-4">Loading content...</div>;
  }

  if (page.blockIds.length === 0) {
    return (
      <div 
        className="text-text-muted text-base leading-relaxed cursor-text py-4 min-h-[100px]"
        onClick={handleCreateInitialBlock}
      >
        Type &apos;/&apos; for commands
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-1 pb-32">
      {page.blockIds.map((blockId, index) => (
        <BlockItem 
          key={blockId} 
          blockId={blockId} 
          index={index}
        />
      ))}
    </div>
  );
}
