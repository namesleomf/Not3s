import { Image as ImageIcon, SmilePlus } from 'lucide-react';
import { useUIStore } from '@/store/useUIStore';
import { useDataStore } from '@/store/useDataStore';
import { usePages } from '@/hooks/usePages';
import { useEffect, useRef } from 'react';
import { BlockEditor } from './BlockEditor';

export function PageSurface() {
  const { selectedPageId } = useUIStore();
  const page = useDataStore(state => selectedPageId ? state.pages[selectedPageId] : null);
  const { updatePage } = usePages();
  const titleInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (titleInputRef.current && page) {
      // Only update if the value is different to avoid cursor jumping
      if (titleInputRef.current.value !== page.title) {
        titleInputRef.current.value = page.title;
      }
    }
  }, [page]);

  if (!page) {
    return (
      <div className="flex items-center justify-center h-full text-text-muted">
        Select or create a page
      </div>
    );
  }

  const handleTitleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    updatePage(page.id, { title: e.target.value });
  };

  return (
    <div className="max-w-4xl mx-auto px-8 py-12 lg:px-12 lg:py-16 w-full">
      {/* Page Header Area */}
      <div className="group mb-8">
        {/* Actions that appear on hover/focus in a real app */}
        <div className="flex items-center gap-2 mb-4 opacity-0 group-hover:opacity-100 focus-within:opacity-100 transition-opacity">
          <button className="chip-button px-3 py-1.5 text-sm gap-2">
            <SmilePlus className="w-4 h-4" strokeWidth={1.5} />
            Add icon
          </button>
          <button className="chip-button px-3 py-1.5 text-sm gap-2">
            <ImageIcon className="w-4 h-4" strokeWidth={1.5} />
            Add cover
          </button>
        </div>
        
        {/* Title Input */}
        <input 
          ref={titleInputRef}
          type="text" 
          placeholder="Untitled"
          onChange={handleTitleChange}
          className="w-full text-4xl lg:text-5xl font-semibold bg-transparent border-none outline-none text-text-primary placeholder:text-text-muted tracking-tight"
        />
      </div>

      {/* Editor Content Area */}
      <BlockEditor pageId={page.id} />
    </div>
  );
}
