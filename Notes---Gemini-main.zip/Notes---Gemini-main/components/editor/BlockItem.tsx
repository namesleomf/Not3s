import React, { useRef, useEffect, useState } from 'react';
import { useDataStore } from '@/store/useDataStore';
import { useBlocks } from '@/hooks/useBlocks';
import { GripVertical, Plus } from 'lucide-react';
import { cn } from '@/lib/utils';
import { BlockType } from '@/types';

interface BlockItemProps {
  blockId: string;
  index: number;
}

export function BlockItem({ blockId, index }: BlockItemProps) {
  const block = useDataStore(state => state.blocks[blockId]);
  const { updateBlock, createBlock, deleteBlock } = useBlocks();
  const contentRef = useRef<HTMLDivElement>(null);
  const [isFocused, setIsFocused] = useState(false);

  useEffect(() => {
    if (contentRef.current && block && contentRef.current.innerText !== block.content) {
      contentRef.current.innerText = block.content;
    }
  }, [block]);

  if (!block) return null;

  const handleInput = (e: React.FormEvent<HTMLDivElement>) => {
    const newContent = e.currentTarget.innerText;
    updateBlock(blockId, { content: newContent });
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      createBlock(block.pageId, 'paragraph', '', block.parentId, index + 1);
    } else if (e.key === 'Backspace' && block.content === '') {
      e.preventDefault();
      deleteBlock(blockId);
      // Focus previous block if possible (simplified)
    }
  };

  const renderBlockContent = () => {
    const commonProps = {
      contentEditable: true,
      suppressContentEditableWarning: true,
      onInput: handleInput,
      onKeyDown: handleKeyDown,
      onFocus: () => setIsFocused(true),
      onBlur: () => setIsFocused(false),
      className: "outline-none min-h-[1.5em] empty:before:content-[attr(data-placeholder)] empty:before:text-text-muted cursor-text",
      'data-placeholder': block.type === 'paragraph' ? "Type '/' for commands" : "",
    };

    switch (block.type) {
      case 'h1':
        return <h1 ref={contentRef} {...commonProps} className={cn(commonProps.className, "text-3xl font-bold mt-6 mb-2")} />;
      case 'h2':
        return <h2 ref={contentRef} {...commonProps} className={cn(commonProps.className, "text-2xl font-semibold mt-5 mb-2")} />;
      case 'h3':
        return <h3 ref={contentRef} {...commonProps} className={cn(commonProps.className, "text-xl font-medium mt-4 mb-1")} />;
      case 'quote':
        return (
          <blockquote className="border-l-4 border-border-strong pl-4 my-2 italic text-text-secondary">
            <div ref={contentRef} {...commonProps} />
          </blockquote>
        );
      case 'todo':
        return (
          <div className="flex items-start gap-2 my-1">
            <input 
              type="checkbox" 
              className="mt-1.5 w-4 h-4 rounded border-border-strong text-text-primary focus:ring-text-primary"
              checked={block.metadata?.checked || false}
              onChange={(e) => updateBlock(blockId, { metadata: { ...block.metadata, checked: e.target.checked } })}
            />
            <div ref={contentRef} {...commonProps} className={cn(commonProps.className, "flex-1", block.metadata?.checked && "line-through text-text-muted")} />
          </div>
        );
      case 'bullet_list':
        return (
          <div className="flex items-start gap-2 my-1">
            <span className="mt-1.5 w-1.5 h-1.5 rounded-full bg-text-primary shrink-0" />
            <div ref={contentRef} {...commonProps} className={cn(commonProps.className, "flex-1")} />
          </div>
        );
      case 'numbered_list':
        return (
          <div className="flex items-start gap-2 my-1">
            <span className="mt-0.5 text-text-secondary select-none shrink-0 w-5 text-right">{index + 1}.</span>
            <div ref={contentRef} {...commonProps} className={cn(commonProps.className, "flex-1")} />
          </div>
        );
      case 'code':
        return (
          <div className="bg-bg-hover rounded-md p-4 my-2 font-mono text-sm overflow-x-auto">
            <div ref={contentRef} {...commonProps} className={cn(commonProps.className, "whitespace-pre")} />
          </div>
        );
      case 'divider':
        return <hr className="my-4 border-border-subtle" />;
      case 'paragraph':
      default:
        return <div ref={contentRef} {...commonProps} className={cn(commonProps.className, "text-base leading-relaxed my-1")} />;
    }
  };

  return (
    <div className="group flex items-start -ml-12 pl-4 pr-4 py-0.5 relative transition-all duration-200 active:scale-[0.99]">
      {/* Block Controls (Hover) */}
      <div className={cn(
        "absolute left-0 top-1.5 flex items-center gap-0.5 opacity-0 transition-opacity",
        "group-hover:opacity-100",
        isFocused && "opacity-100"
      )}>
        <button 
          className="p-1 text-text-muted hover:text-text-primary hover:bg-bg-hover rounded-sm transition-all duration-200 active:scale-90"
          onClick={() => createBlock(block.pageId, 'paragraph', '', block.parentId, index + 1)}
        >
          <Plus className="w-4 h-4" />
        </button>
        <button 
          className="p-1 text-text-muted hover:text-text-primary hover:bg-bg-hover rounded-sm transition-all duration-200 active:scale-90 cursor-grab active:cursor-grabbing"
        >
          <GripVertical className="w-4 h-4" />
        </button>
      </div>

      {/* Block Content */}
      <div className="flex-1 min-w-0 ml-8">
        {renderBlockContent()}
      </div>
    </div>
  );
}
