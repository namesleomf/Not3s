import { Type, Heading1, Heading2, Heading3, List, ListOrdered, CheckSquare, Quote, Code, Minus, Bold, Italic, Underline, Strikethrough } from 'lucide-react';
import { useUIStore } from '@/store/useUIStore';
import { useDataStore } from '@/store/useDataStore';
import { useBlocks } from '@/hooks/useBlocks';
import { BlockType } from '@/types';
import { cn } from '@/lib/utils';

export function FloatingToolbar() {
  const { focusedBlockId, selectedPageId } = useUIStore();
  const block = useDataStore(state => focusedBlockId ? state.blocks[focusedBlockId] : null);
  const { updateBlockType } = useBlocks(selectedPageId);

  if (!block) return null;

  const handleTypeChange = (type: BlockType) => {
    if (focusedBlockId) {
      updateBlockType(focusedBlockId, type);
    }
  };

  const handleFormat = (command: string) => {
    document.execCommand(command, false, '');
  };

  const isActive = (type: BlockType) => block.type === type;

  return (
    <div className="fixed bottom-8 left-1/2 -translate-x-1/2 z-40">
      <div className="pill-toolbar" onMouseDown={(e) => e.preventDefault()}>
        <button 
          onClick={() => handleFormat('bold')}
          className="icon-button w-8 h-8 mx-0.5"
          title="Bold (Cmd+B)"
        >
          <Bold className="w-4 h-4" strokeWidth={2} />
        </button>
        <button 
          onClick={() => handleFormat('italic')}
          className="icon-button w-8 h-8 mx-0.5"
          title="Italic (Cmd+I)"
        >
          <Italic className="w-4 h-4" strokeWidth={2} />
        </button>
        <button 
          onClick={() => handleFormat('underline')}
          className="icon-button w-8 h-8 mx-0.5"
          title="Underline (Cmd+U)"
        >
          <Underline className="w-4 h-4" strokeWidth={2} />
        </button>
        <button 
          onClick={() => handleFormat('strikeThrough')}
          className="icon-button w-8 h-8 mx-0.5"
          title="Strikethrough"
        >
          <Strikethrough className="w-4 h-4" strokeWidth={2} />
        </button>

        <div className="w-[1px] h-4 bg-border-strong mx-1" />

        <button 
          onClick={() => handleTypeChange('paragraph')}
          className={cn("icon-button w-8 h-8 mx-0.5", isActive('paragraph') && "bg-bg-active text-text-primary")}
        >
          <Type className="w-4 h-4" strokeWidth={1.5} />
        </button>
        <button 
          onClick={() => handleTypeChange('h1')}
          className={cn("icon-button w-8 h-8 mx-0.5", isActive('h1') && "bg-bg-active text-text-primary")}
        >
          <Heading1 className="w-4 h-4" strokeWidth={1.5} />
        </button>
        <button 
          onClick={() => handleTypeChange('h2')}
          className={cn("icon-button w-8 h-8 mx-0.5", isActive('h2') && "bg-bg-active text-text-primary")}
        >
          <Heading2 className="w-4 h-4" strokeWidth={1.5} />
        </button>
        <button 
          onClick={() => handleTypeChange('h3')}
          className={cn("icon-button w-8 h-8 mx-0.5", isActive('h3') && "bg-bg-active text-text-primary")}
        >
          <Heading3 className="w-4 h-4" strokeWidth={1.5} />
        </button>
        
        <div className="w-[1px] h-4 bg-border-strong mx-1" />
        
        <button 
          onClick={() => handleTypeChange('bullet_list')}
          className={cn("icon-button w-8 h-8 mx-0.5", isActive('bullet_list') && "bg-bg-active text-text-primary")}
        >
          <List className="w-4 h-4" strokeWidth={1.5} />
        </button>
        <button 
          onClick={() => handleTypeChange('numbered_list')}
          className={cn("icon-button w-8 h-8 mx-0.5", isActive('numbered_list') && "bg-bg-active text-text-primary")}
        >
          <ListOrdered className="w-4 h-4" strokeWidth={1.5} />
        </button>
        <button 
          onClick={() => handleTypeChange('todo')}
          className={cn("icon-button w-8 h-8 mx-0.5", isActive('todo') && "bg-bg-active text-text-primary")}
        >
          <CheckSquare className="w-4 h-4" strokeWidth={1.5} />
        </button>
        
        <div className="w-[1px] h-4 bg-border-strong mx-1" />
        
        <button 
          onClick={() => handleTypeChange('quote')}
          className={cn("icon-button w-8 h-8 mx-0.5", isActive('quote') && "bg-bg-active text-text-primary")}
        >
          <Quote className="w-4 h-4" strokeWidth={1.5} />
        </button>
        <button 
          onClick={() => handleTypeChange('code')}
          className={cn("icon-button w-8 h-8 mx-0.5", isActive('code') && "bg-bg-active text-text-primary")}
        >
          <Code className="w-4 h-4" strokeWidth={1.5} />
        </button>
        <button 
          onClick={() => handleTypeChange('divider')}
          className={cn("icon-button w-8 h-8 mx-0.5", isActive('divider') && "bg-bg-active text-text-primary")}
        >
          <Minus className="w-4 h-4" strokeWidth={1.5} />
        </button>
      </div>
    </div>
  );
}
