import { Modal } from '@/components/ui/Modal';
import { useUIStore } from '@/store/useUIStore';
import { Monitor, Moon, Sun } from 'lucide-react';
import { cn } from '@/lib/utils';

export function SettingsModal() {
  const { activeModal, setActiveModal, theme, setTheme } = useUIStore();
  const isOpen = activeModal === 'settings';
  const onClose = () => setActiveModal('none');

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Settings" maxWidth="max-w-2xl">
      <div className="space-y-8">
        <section>
          <h3 className="text-sm font-medium text-text-secondary mb-3">Appearance</h3>
          <div className="grid grid-cols-3 gap-3">
            {[
              { id: 'system', label: 'System', icon: Monitor },
              { id: 'paper-white', label: 'Paper White', icon: Sun },
              { id: 'oled-black', label: 'OLED Black', icon: Moon },
            ].map((t) => (
              <button
                key={t.id}
                onClick={() => setTheme(t.id as any)}
                className={cn(
                  "flex flex-col items-center justify-center p-4 rounded-[var(--radius-lg)] border transition-all duration-200 active:scale-95",
                  theme === t.id 
                    ? "border-text-primary bg-bg-hover" 
                    : "border-border-subtle hover:border-border-strong hover:bg-bg-hover"
                )}
              >
                <t.icon className="w-6 h-6 mb-2 text-text-primary" strokeWidth={1.5} />
                <span className="text-sm font-medium text-text-primary">{t.label}</span>
              </button>
            ))}
          </div>
        </section>
        
        <section>
          <h3 className="text-sm font-medium text-text-secondary mb-3">Workspace</h3>
          <div className="space-y-2">
            <div className="flex items-center justify-between p-3 rounded-[var(--radius-md)] border border-border-subtle">
              <div>
                <div className="text-sm font-medium text-text-primary">Confirm before delete</div>
                <div className="text-xs text-text-muted">Ask for confirmation when moving pages to trash</div>
              </div>
              <div className="w-10 h-6 bg-text-primary rounded-full relative cursor-pointer">
                <div className="absolute right-1 top-1 w-4 h-4 bg-bg-app rounded-full" />
              </div>
            </div>
          </div>
        </section>
      </div>
    </Modal>
  );
}
