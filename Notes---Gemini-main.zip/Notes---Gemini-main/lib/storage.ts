import { openDB, DBSchema, IDBPDatabase } from 'idb';
import { Page, Block, Settings, ImportJob } from '@/types';

interface AppDB extends DBSchema {
  pages: {
    key: string;
    value: Page;
    indexes: { 'by-parent': string; 'by-trashed': number };
  };
  blocks: {
    key: string;
    value: Block;
    indexes: { 'by-page': string };
  };
  settings: {
    key: string;
    value: Settings;
  };
  imports: {
    key: string;
    value: ImportJob;
  };
}

let dbPromise: Promise<IDBPDatabase<AppDB>> | null = null;

export const getDB = () => {
  if (!dbPromise) {
    dbPromise = openDB<AppDB>('knowledge-workspace-db', 1, {
      upgrade(db) {
        // Pages Store
        const pageStore = db.createObjectStore('pages', { keyPath: 'id' });
        pageStore.createIndex('by-parent', 'parentId');
        pageStore.createIndex('by-trashed', 'isTrashed');

        // Blocks Store
        const blockStore = db.createObjectStore('blocks', { keyPath: 'id' });
        blockStore.createIndex('by-page', 'pageId');

        // Settings Store (Single row typically, key = 'user-settings')
        db.createObjectStore('settings');

        // Imports Store
        db.createObjectStore('imports', { keyPath: 'id' });
      },
    });
  }
  return dbPromise;
};

// --- Storage Abstraction Methods ---

export const loadPages = async (): Promise<Page[]> => {
  const db = await getDB();
  return db.getAll('pages');
};

export const savePage = async (page: Page): Promise<void> => {
  const db = await getDB();
  await db.put('pages', page);
};

export const deletePage = async (id: string): Promise<void> => {
  const db = await getDB();
  await db.delete('pages', id);
};

export const loadBlocks = async (): Promise<Block[]> => {
  const db = await getDB();
  return db.getAll('blocks');
};

export const loadBlocksForPage = async (pageId: string): Promise<Block[]> => {
  const db = await getDB();
  return db.getAllFromIndex('blocks', 'by-page', pageId);
};

export const saveBlock = async (block: Block): Promise<void> => {
  const db = await getDB();
  await db.put('blocks', block);
};

export const deleteBlock = async (id: string): Promise<void> => {
  const db = await getDB();
  await db.delete('blocks', id);
};

export const loadSettings = async (): Promise<Settings | undefined> => {
  const db = await getDB();
  return db.get('settings', 'user-settings');
};

export const saveSettings = async (settings: Settings): Promise<void> => {
  const db = await getDB();
  await db.put('settings', settings, 'user-settings');
};
