import { Block } from '@/types';

export interface ImportParser {
  /**
   * The file extensions this parser supports (e.g., ['.md', '.markdown'])
   */
  supportedExtensions: string[];
  
  /**
   * Parses a raw file into an array of partial blocks.
   * The caller (useImport hook) is responsible for assigning IDs, pageIds, and saving them.
   */
  parse(file: File): Promise<Partial<Block>[]>;
}

/**
 * IMPORT ARCHITECTURE & CONVERSION RULES
 * 
 * 1. MARKDOWN (.md)
 * - Read as text.
 * - Split by `\n\n` or use a lightweight regex parser.
 * - Identify headings (`#`), lists (`-`, `*`, `1.`), blockquotes (`>`), code blocks (```).
 * - Convert to respective `BlockType` (e.g., 'h1', 'bullet_list', 'code').
 * - Fallback: Any unrecognized text becomes a 'paragraph' block.
 * 
 * 2. HTML (.html)
 * - Parse using `DOMParser`.
 * - Traverse the `<body>` element.
 * - Map `<h1>`-`<h6>` to heading blocks, `<ul>`/`<ol>` to list blocks, `<p>` to paragraphs.
 * - Strip noisy presentation markup (inline styles, classes).
 * - Fallback: Extract `innerText` and split into paragraphs if structure is too messy.
 * 
 * 3. CSV (.csv)
 * - Read as text.
 * - Split by newlines and commas (handling quotes).
 * - Convert the first row to a table header, and the rest to table rows.
 * - Store as a single 'table' block with `metadata` containing the 2D array data.
 * 
 * 4. PDF (.pdf)
 * - Due to browser limitations, full structural extraction is difficult without heavy WASM libraries.
 * - Fallback 1: Use a lightweight text extraction library to pull raw text and segment into paragraphs.
 * - Fallback 2: If text extraction fails, create an 'attachment' block referencing the file.
 */
